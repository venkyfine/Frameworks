//
//  LoginViewModel.swift
//  OktaDemo

import UIKit
import OktaAuthSdk

struct LoginViewModel {

    func login(username: String, password: String, success: @escaping (_ idToken: String) -> Void, failure:@escaping (_ message: String) -> Void ) {
        
        OktaManager.shared.login(username: username, password: password) { tokenManager, error in
            if let error = error as? OktaError {
                failure(error.localizedDescription)
            } else if let error = error {
                failure(error.localizedDescription)
            }
            if error == nil && tokenManager != nil {
                tokenManager?.getUser({ result, _ in
                    print(result)
                    let authToken = tokenManager?.accessToken ?? ""
                    success(authToken)
                })
            }
        }
       
    }
}
